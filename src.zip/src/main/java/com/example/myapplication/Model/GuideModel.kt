package com.example.myapplication.Model

data class GuideModel(
    var guideId: String? = null,
    var guideName: String? = null,
    var guidePNum: String? = null,
    var guideLan: String? = null,
    var guideHours: String? = null



)