package com.example.myapplication.Model

data class UserModel(
    var userId: String? = null,
    var userName: String? = null,
    var userPNum: String? = null,
    var userEmail: String? = null,
    var userCountry: String? = null
)  