package com.example.myapplication.Model

data class CarModel (
    var carId: String? = null,
    var cmodel: String? = null,
    var vnumber: String? = null,
    var seatc: String? = null,
    var cprice: String? = null,
    var pname: String? = null,
    var pphone: String? = null,
    var pemail: String? = null,

)