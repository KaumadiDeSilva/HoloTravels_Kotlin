package com.example.myapplication.Transport

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import com.example.myapplication.MainActivity
import com.example.myapplication.R

class Category: AppCompatActivity() {

    lateinit var btnviewcategory: Button
    lateinit var btnviewcategory1: Button
    lateinit var btnviewcategory2: Button
    lateinit var backbutton1: Button

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.category)


        backbutton1 = findViewById(R.id.button1000)
        btnviewcategory =  findViewById(R.id.button3)
        btnviewcategory1 =  findViewById(R.id.button4)
        btnviewcategory2 =  findViewById(R.id.button5)
        btnviewcategory.setOnClickListener {
            val intent = Intent(this, Category1::class.java)
            startActivity(intent)
        }

        backbutton1.setOnClickListener {
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
        }
        btnviewcategory1.setOnClickListener {
            val intent = Intent(this, UC::class.java)
            startActivity(intent)
        }
        btnviewcategory2.setOnClickListener {
            val intent = Intent(this, UC::class.java)
            startActivity(intent)
        }
    }
}